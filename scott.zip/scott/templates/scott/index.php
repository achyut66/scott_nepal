<?php

defined('_JEXEC') or die;
error_reporting(0);

$app             = JFactory::getApplication();
$doc             = JFactory::getDocument();
$user            = JFactory::getUser();
$this->language  = $doc->language;
$this->direction = $doc->direction;

// Getting params from template
$params = $app->getTemplate(true)->params;

// Detecting Active Variables
$option   = $app->input->getCmd('option', '');
$view     = $app->input->getCmd('view', '');
$layout   = $app->input->getCmd('layout', '');
$task     = $app->input->getCmd('task', '');
$itemid   = $app->input->getCmd('Itemid', '');
$sitename = $app->get('sitename');

// Add JavaScript Frameworks
JHtml::_('bootstrap.framework');
$doc->addScript($this->baseurl . '/templates/' . $this->template . '/js/template.js');

// Add Stylesheets
$doc->addStyleSheet($this->baseurl . '/templates/' . $this->template . '/css/bootstrap.css');
$doc->addStyleSheet($this->baseurl . '/templates/' . $this->template . '/css/template.css');

// Load optional RTL Bootstrap CSS
JHtml::_('bootstrap.loadCss', false, $this->direction);


?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<jdoc:include type="head" />
   
    
    
	<!--[if lt IE 9]>
		<script src="<?php echo JUri::root(true); ?>/media/jui/js/html5.js"></script>
	<![endif]-->
</head>

<body>
	<?php  $menu =& JSite::getMenu();    // Load the menu
		$active = $menu->getActive(); // Get the current active menu
		if ($active->home ==1) {  ?>
    
    <div id="top_wrap">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-3 col-md-3 col-sm-12 col-xs-12 toptel">
                	<jdoc:include type="modules" name="scott-toptel" style="none" />
                </div>
                <div class="col col-lg-3 col-md-3 col-sm-12 col-xs-12 topemail">
                	<jdoc:include type="modules" name="scott-topemail" style="none" />
                </div>
                
                <div class="col col-lg-4 col-md-3 col-sm-12 col-xs-12 topaddress">
                	<jdoc:include type="modules" name="scott-topaddress" style="none" />
                </div>
                <div class="col col-lg-2 col-md-3 col-sm-12 col-xs-12 topsocial">
                	<jdoc:include type="modules" name="scott-topsocial" style="none" />
                </div>
           </div>
        </div>
    </div><!-- top wrap ends -->
    <div id="title_wrap" >
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-4 col-md-3 col-sm-12 col-xs-12 logo">
           	 		<img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/images/logo.png" alt="scott & scotts, Logo"/> 
                </div>
                <div class="col col-lg-4 col-md-6 col-sm-12 col-xs-12 ">
                	
                </div> 
                <div class="col col-lg-4 col-md-3 col-sm-12 col-xs-12 topsearch">
                	<jdoc:include type="modules" name="scott-search" style="none" />
                </div>                
                	
            </div>
        </div>
    </div><!-- title wrap ends --> 
    <div id="mainmenu" class="title_wrap">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12 mainmenu">
                    <jdoc:include type="modules" name="scott-mainmenu" style="none"/>                
                </div>
            </div>
        </div>
    </div><!-- main menu ends -->
    <div id="banner" class="img-responsive">
    	<jdoc:include type="modules" name="scott-banner" />
    </div><!-- banner ends -->
     <div id="mycontent">
    	<div class="container">
        	<div class="content row">
            	<jdoc:include type="message" />
                <jdoc:include type="component" />
            </div>
        </div>
    </div><!-- content ends -->
    <div id="services">
    	<div class="container">
        	<div class="content row">
            			<h2>Our Brands</h2>
            	<div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12">                	
        			<jdoc:include type="modules" name="scott-brands" style="none" />
                </div>
                
            </div>
        </div>
    </div><!-- banner ends -->
    
    
   <div id="frontpageportfolio">
    	<div class="container">
        	<div class="content row">
            	<h2>New Arrivals</h2>
                    <div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    	<jdoc:include type="modules" name="scott-packages" style="xthml" />                
                    </div>
                                
            </div>
        </div>
    </div><!-- banner ends -->
    
    <div id="bottom">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
                	<jdoc:include type="modules" name="scott-footer1" style="xhtml" />
                </div>
                <div class="col col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
                	<jdoc:include type="modules" name="scott-footer2" style="xhtml" />
                </div>
                <div class="col col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
                	<jdoc:include type="modules" name="scott-footer3" style="xhtml" />
                </div>
            </div>
        </div>
    </div><!-- footer ends -->
    
    <div id="footer">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-6 col-md-6 col-sm-12 col-xs-12">
                	Copyright &copy; 2018. All Rights Reserved.
                </div>
                <div class="col col-lg-6 col-md-6 col-sm-12 col-xs-12 myright">
                	Scott &amp; Scotts Nepal Pvt Ltd.
                </div>
            </div>
        </div>
    </div><!-- footer ends -->
    <?php } else { ?>
    <div id="top_wrap">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-3 col-md-3 col-sm-12 col-xs-12 topemail">
                	<jdoc:include type="modules" name="scott-topemail" style="none" />
                </div>
                <div class="col col-lg-3 col-md-3 col-sm-12 col-xs-12 toptel">
                	<jdoc:include type="modules" name="scott-toptel" style="none" />
                </div>
                <div class="col col-lg-4 col-md-3 col-sm-12 col-xs-12 topaddress">
                	<jdoc:include type="modules" name="scott-topaddress" style="none" />
                </div>
                <div class="col col-lg-2 col-md-3 col-sm-12 col-xs-12 topsocial">
                	<jdoc:include type="modules" name="scott-topsocial" style="none" />
                </div>
           </div>
        </div>
    </div><!-- top wrap ends -->
    <div id="title_wrap" >
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-4 col-md-3 col-sm-12 col-xs-12 logo">
           	 		<img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/images/logo.png" alt="Scott &amp; Scotts Logo"/> 
                </div>
                <div class="col col-lg-4 col-md-6 col-sm-12 col-xs-12 ">
                	
                </div> 
                <div class="col col-lg-4 col-md-3 col-sm-12 col-xs-12 topsearch">
                	<jdoc:include type="modules" name="scott-search" style="none" />
                </div>                  
                	
            </div>
        </div>
    </div><!-- title wrap ends -->
    <div id="mainmenu" class="title_wrap">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12 mainmenu">
                    <jdoc:include type="modules" name="scott-mainmenu" style="none"/>                
                </div>
            </div>
        </div>
    </div><!-- main menu ends -->
    <div id="breadcrumb">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12">
                	<jdoc:include type="modules" name="scott-breadcrumb" style="none"/>
                </div>
            </div>
        </div>
    </div><!-- bread crumb ends --> 
     <div id="mycontentnext">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <jdoc:include type="message" />
                    <jdoc:include type="component" />
                    <div class="fullwidth">
                        <div class="myform">
                            <jdoc:include type="modules" name="scott-form" style="xhtml" class="formhere" />
                        </div>
                        <div class="contactinfo">
                            <jdoc:include type="modules" name="scott-contactinfo" style="xhtml" />
                        </div>
                        <div class="myspacer"></div>
                        <div class="ourlocations">
                        	<jdoc:include type="modules" name="scott-ourlocations" style="xhtml" />
                        </div>
                      
                    </div>
                    <div class="productlist"><jdoc:include type="modules" name="scott-products" style="xhtml" /></div>
                    <div class="portfolio"><jdoc:include type="modules" name="scott-portfolio" style="xhtml" /></div>
                </div>
            </div>
        </div>
    </div><!-- content ends -->
    
     
    <div id="footer">
    	<div class="container">
        	<div class="content row">
            	<div class="col col-lg-6 col-md-6 col-sm-12 col-xs-12">
                	Copyright &copy; 2018. All Rights Reserved.
                </div>
                <div class="col col-lg-6 col-md-6 col-sm-12 col-xs-12 myright">
                	Scott &amp; Scotts Nepal Pvt Ltd.
                </div>
            </div>
        </div>
    </div><!-- footer ends -->
    <?php } ?>
    
    
    
	<jdoc:include type="modules" name="debug" style="none" />
</body>
</html>
